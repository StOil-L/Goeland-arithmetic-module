/*************/
/* parser.go */
/*************/
/**
* This file provides function to manage the simplex algorithm.
**/

package ari
