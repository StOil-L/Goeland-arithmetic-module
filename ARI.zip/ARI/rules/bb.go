/*************/
/* bb.go */
/*************/
/**
* This file provides function to manage the branch and bound algorithm.
**/

package ari
