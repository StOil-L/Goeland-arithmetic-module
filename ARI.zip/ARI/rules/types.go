/*************/
/* parser.go */
/*************/
/**
* This file provides the data-structure for arithmetic's problems.
**/

package ari
